#!/system/bin/sh
#此脚本来自ClearBox模块，用于设置内部储存应用阻止缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
Appdir="/data/user/0"
Appdir2="/data/user_de/0"
blacklist="$work_dir/RunStart"
whitelist="$work_dir/whitelist.prop"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
ls $Appdir | while read dir; do
    if grep "$dir" "$whitelist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    elif ! grep "$dir" "$blacklist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    elif grep "$dir" "$blacklist" >/dev/null; then
        rm -r "$Appdir"/"$dir"/cache/*
        rm -r "$Appdir2"/"$dir"/cache/*
        rm -r "$Appdir"/"$dir"/code_cache/*
        rm -r "$Appdir2"/"$dir"/code_cache/*
        chmod 2551 "$Appdir"/"$dir"/cache
        chmod 2551 "$Appdir2"/"$dir"/cache
        chmod 2551 "$Appdir"/"$dir"/code_cache
        chmod 2551 "$Appdir2"/"$dir"/code_cache
    fi
done

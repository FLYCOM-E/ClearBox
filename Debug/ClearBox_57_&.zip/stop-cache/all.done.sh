#!/system/bin/sh
#此脚本来自ClearBox模块，用于启动运行阻止缓存脚本
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
mkdir -p "$work_dir"
######
if [ ! -f "$work_dir/RunStart" ]; then
    touch "$work_dir/RunStart"
elif [ ! -f "$work_dir/whitelist.prop" ]; then
    touch "$work_dir/whitelist.prop"
elif [ -f "$work_dir/blacklist.prop" ]; then
    rm "$work_dir/blacklist.prop"
fi
######
if cat "$work_dir/settings.prop" | grep "stopcache=0" >/dev/null; then
    echo "#" > "$work_dir/RunStart"
elif dumpsys power | grep "Display Power:" | grep "ON" >/dev/null; then
    dumpsys window | grep mCurrentFocus | "$bin_dir/busybox" awk -F 'u0 |/' '{print $2}' > "$work_dir/RunStart"
fi
######
echo " 正在设置中..."
   sh "$home_dir/stop-cache/stop_usercache.sh" &
   sh "$home_dir/stop-cache/stop_micro-cache.sh" &
   wait
echo " 完成！"

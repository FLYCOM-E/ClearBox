#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除/data/user_de内缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
for user2cache in $(ls /data/user_de/0); do
    rm -r /data/user_de/0/"$user2cache"/cache/*
    rm -r /data/user_de/0/"$user2cache"/code_cache/*
    echo " $user2cache 缓存已清除"
done
echo " -- user_de 缓存删除完成"

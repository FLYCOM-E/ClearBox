#!/system/bin/sh
#此脚本来自ClearBox模块，用于进行紧急GC优化，原理来自Coolapk@Amktiao，感谢大佬
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
get_f2fs_sysfs="/sys/fs/f2fs/$(getprop dev.mnt.dev.data)"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
if [ ! -d "$get_f2fs_sysfs" ]; then
    echo " 您的设备不是 F2FS 文件系统"
    echo " 维护仅支持 F2FS 环境"
    exit 0
elif [ ! -f "$get_f2fs_sysfs/gc_urgent" ]; then
    echo " 您的设备不支持当前GC功能"
    exit 0
fi
######
echo " 目前脏段:$(cat "$get_f2fs_sysfs/dirty_segments")"
echo " 目前空闲段:$(cat "$get_f2fs_sysfs/free_segments")"
######
echo " GC已开始, 请您耐心等待"
echo 1 > "$get_f2fs_sysfs/gc_urgent"
while true; do
    if [ $(cat "$get_f2fs_sysfs/gc_urgent") = "0" ]; then
        break
    fi
    sleep 3
done

#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
#检查root
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
#定义变量
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"
chmod -R 777 ./*
mkdir -p "$work_dir"
#打开了阻止安装功能则还原（防止卡开机
if [ -f "$work_dir/S_stop_upapp" ]; then
    chmod 771 /data/app
fi
#检测开机
while true; do
    if [ -d "/storage/emulated/0/Android/data" ]; then
        break
    fi
sleep 2
done
#备份黑名单
if [ -f "$work_dir/blacklist.txt" ]; then
    cp "$work_dir/blacklist.txt" "$home_dir/stop-cache/blacklist.txt"
fi
#检测到阻止缓存被关闭则还原目录权限状态
if [ -f "$work_dir/log" ]; then
    echo "" > "$work_dir/blacklist.txt"
    sh "$home_dir/stop-cache/all.done.sh"
    wait
fi
#阻止缓存开启则运行脚本
if [ -f "$work_dir/S_stop_cache" ]; then
    sh "$home_dir/stop-cache/all.done.sh"
    wait
    echo " 上次运行时间：$(date)" >> "$work_dir/运行日志.log"
fi
#阻止安装开启则设置app目录权限
if [ -f "$work_dir/S_stop_upapp" ]; then
    chmod 551 /data/app
fi
#删除模块目录管理app文件
"$bin_dir/busybox" find "$home_dir"/ -type f -name "*.apk" -delete
#备份定时清理配置
if [ -f "$work_dir/root_backup" ]; then
    cp "$work_dir/root_backup" "$home_dir/CRON/root"
fi
cp "$home_dir/CRON/root" "$work_dir/root_backup"
wait
#定时清理
"$bin_dir/busybox" crond -c "$home_dir"/CRON

exit 0

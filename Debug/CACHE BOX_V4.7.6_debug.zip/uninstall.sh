#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
#检查root
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
#定义变量
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
#还原关闭阻止安装
if [ -f "$work_dir/S_stop_upapp" ]; then
    chmod 771 /data/app
fi
#还原关闭阻止缓存
touch "$work_dir/log"
echo "" > "$work_dir/blacklist.txt"
sh "$home_dir/service.sh"
wait
#删除工作目录并卸载软件
rm -r "$work_dir"
touch "$home_dir/remove"
echo " 3秒后卸载软件！"
echo " 感谢您的使用与支持，欢迎下次光临！！"
sleep 3
pm uninstall "wipe.cache.module"
exit 0

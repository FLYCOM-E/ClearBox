#!/system/bin/sh
#此脚本用于删除/data/内缓存

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"

ls /data/data/ | while read user1cache; do
    rm -rf /data/data/"$user1cache"/cache/*
    rm -rf /data/data/"$user1cache"/code_cache/*
    [[ $? -eq 0 ]] && echo "$user1cache 缓存已清除"
done
echo "-- user 缓存删除完成"

#!/system/bin/sh
#此脚本用于删除垃圾缓存及空文件夹
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep -)
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"
ls "$dir"/Android/data | while read c; do
    rm -rf "$dir"/Android/data/"$c"/cache/*
    [[ $? -eq 0 ]] && echo "$c 缓存已清除"
done
rm -rf "$dir"/Pictures/.thumbnails/*
rm -rf "$dir"/Movies/.thumbnails/*
rm -rf "$dir"/music/.thumbnails/*
rm -rf "$dir"/Music/.thumbnails/*
"$bin_dir/busybox" find "$dir" -type d -empty -delete
if [ ! "$dir2" = "" ]; then
    ls "$dir2"/Android/data | while read v; do
        rm -rf "$F"/Android/data/"$v"/cache/*
    [[ $? -eq 0 ]] && echo "$v 缓存已清除"
    done
    rm -rf "$dir2"/Pictures/.thumbnails/*
    rm -rf "$dir2"/Movies/.thumbnails/*
    rm -rf "$dir2"/music/.thumbnails/*
    rm -rf "$dir2"/Music/.thumbnails/*
    "$bin_dir/busybox" find "$dir2" -type d -empty -delete
fi
echo "sdcard垃圾删除完成！"
exit 0

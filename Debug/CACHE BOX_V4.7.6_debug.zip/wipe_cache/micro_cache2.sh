#!/system/bin/sh
#此段用于删除sd安装软件user_de缓存清除

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"

in_dir=$(ls /mnt/expand)
if [ "$in_dir" = "" ]; then
    exit 0
fi

ls /mnt/expand/*/user_de/0/ | while read micro2cache; do
    rm -rf /mnt/expand/*/user_de/0/"$micro2cache"/cache/*
    rm -rf /mnt/expand/*/user_de/0/"$micro2cache"/code_cache/*
    [[ $? -eq 0 ]] && echo "$micro2cache 缓存已清除"
done
echo "-- micro-user_de 缓存删除完成"

#!/system/bin/sh
#此脚本用于删除sd安装软件缓存清除

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"

in_dir=$(ls /mnt/expand)
if [ "$in_dir" = "" ]; then
    exit 0
fi

ls /mnt/expand/*/user/0/ | while read microcache; do
    rm -rf /mnt/expand/*/user/0/"$microcache"/cache/*
    rm -rf /mnt/expand/*/user/0/"$microcache"/code_cache/*
    [[ $? -eq 0 ]] && echo "$microcache 缓存已清除"
done
echo "-- micro-user 缓存删除完成"

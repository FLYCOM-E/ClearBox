#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
#检查root
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
#定义变量
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"
#执行清理脚本
sh "$home_dir/wipe_cache/data_cache.sh" &
sh "$home_dir/wipe_cache/data_cache2.sh" &
sh "$home_dir/wipe_cache/micro_cache.sh" &
sh "$home_dir/wipe_cache/micro_cache2.sh" &
sh "$home_dir/wipe_cache/wipe_all_apk.sh" &
sh "$home_dir/wipe_cache/wipe_all_dir.sh" &
sh "$home_dir/wipe_cache/wipe_all_zip.sh" &
wait
#日志
echo " 上次清理时间：$(date)" >> "$work_dir/运行日志.log"
echo " 完成！"

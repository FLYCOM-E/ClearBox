#!/system/bin/sh
#此脚本来自ClearBox模块，用于提供终端菜单
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
V=$(cat "$home_dir/module.prop" | grep "version=" | "$bin_dir/busybox" awk -F '=' '{print $2}')
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 菜单函数
function md_menu()
{
clear
"$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[欢迎使用 ClearBox    "$V"]\033[0m")
 ===================================================

 1：一键优化清理             2：清理干掉自定义目录

 3：清除垃圾文件及空文件夹   4：清空系统缓存
     
 5：深度清理                 6：阻止软件更新安装 
    
 7：阻止缓存生成功能         8：磁铁（一键归类文件

 9：磁盘优化（GC）           00：模块管理

 ===================================================
                                --- 键入 E 退出 ---
 请输入相应序号:"
   read in_put
     case "$in_put" in
       1)
         sh "$home_dir/all.sh" ClearAll &
         wait
         ;;
       2)
         sh "$home_dir/wipe_cache/wipe_list_dir.sh"
         ;;
       3)
         sh "$home_dir/wipe_cache/wipe_all_dir.sh"
         ;;
       4)
         sh "$home_dir/wipe_cache/system_cache.sh"
         ;;
       5)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[深度清理，请备份重要文档！！]\033[0m")
 ===================================================

     1：清除所有APK安装包
    
     2：清除所有压缩包文件

 ===================================================

 请输入相应序号:"
         read put1
           case "$put1" in
             1)
               sh "$home_dir/wipe_cache/wipe_all_apk.sh"
               ;;
             2)
               sh "$home_dir/wipe_cache/wipe_all_zip.sh"
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       6)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[APP更新安装管理]\033[0m")
 ===================================================

     1：阻止APP更新安装
    
     2：关闭阻止更新安装

 ===================================================

 请输入相应序号:"
         read put1
           case "$put1" in
             1)
               chmod 551 /data/app
               echo " 已开启阻止更新！"
               if ! cat "$work_dir/settings.prop" | grep "stopinstall=1" >/dev/null; then
                   sed -i 's/stopinstall=0/stopinstall=1/g' "$work_dir/settings.prop"
               fi
               ;;
             2)
               chmod 771 /data/app
               echo "已关闭阻止更新！"
               sed -i 's/stopinstall=1/stopinstall=0/g' "$work_dir/settings.prop"
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       7)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[阻止缓存]\033[0m")
 ===================================================

     1：开启阻止生成缓存功能
  
     2：关闭阻止生成缓存功能
    
     3：检测开启关闭状态
  
 ===================================================

 请输入相应序号:"
         read put2
           case "$put2" in
             1)
               if ! cat "$work_dir/settings.prop" | grep "stopcache=1" >/dev/null; then
                   sed -i 's/stopcache=0/stopcache=1/g' "$work_dir/settings.prop"
               fi
               echo " 已开启，重启生效 ~"
               ;;
             2)
               sed -i 's/stopcache=1/stopcache=0/g' "$work_dir/settings.prop"
               sh "$home_dir/service.sh" &
               wait
               echo " 已关闭，重启生效 ~"
               ;;
             3)
               if cat "$work_dir/settings.prop" | grep "stopcache=1" >/dev/null; then
                   echo " 阻止缓存处于开启状态！"
               else
                   echo " 阻止缓存处于关闭状态！"
               fi
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       8)
         sh "$home_dir/wipe_cache/file_1.sh" &
         sh "$home_dir/wipe_cache/file_2.sh" &
         wait
         ;;
       9)
         sh "$home_dir/wipe_cache/f2fs_GC.sh"
         ;;
       00)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[模块管理菜单]\033[0m")
 ===================================================

     1：立即生效模块所有配置
     
     2：定期运行优化整理
     
     3：卸载模块(！

 ===================================================

 请输入相应序号:"
         read put3
           case "$put3" in
             1)
               sh "$home_dir/service.sh"
               ;;
             2)
               clear
               "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[设定时间]\033[0m")
 ===================================================
      
      1：每隔 1 天自动运行优化整理
      
      2：每隔 3 天自动运行优化整理
      
      3：每隔 7 天自动运行优化整理
      
      4：每隔 15 天自动运行优化整理
      
      5：每隔 30 天自动运行优化整理
      
      0：关闭定期优化
 
 ===================================================

 请输入相应序号:"
               read put4
                 case "$put4" in
                   1)
                     "$bin_dir/busybox" echo "0 0 */1 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo "0 0 */1 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     echo " 设定成功！"
                     ;;
                   2)
                     "$bin_dir/busybox" echo "0 0 */3 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo "0 0 */3 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     echo " 设定成功！"
                     ;;
                   3)
                     "$bin_dir/busybox" echo "0 0 */7 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo "0 0 */7 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     echo " 设定成功！"
                     ;;
                   4)
                     "$bin_dir/busybox" echo "0 0 */15 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo "0 0 */15 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     echo " 设定成功！"
                     ;;
                   5)
                     "$bin_dir/busybox" echo "0 0 */30 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo "0 0 */30 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     echo " 设定成功！"
                     ;;
                   0)
                     "$bin_dir/busybox" echo -n "" > "$home_dir/CRON/root"
                     "$bin_dir/busybox" echo -n "" > "$work_dir/root_backup"
                     echo " 已关闭定期优化！"
                     ;;
                   *)
                     "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                     ;;
                 esac
                 ;;
             3)
               echo " 是否卸载模块？(y/n)"
               read unput
               case "$unput" in
                 y)
                   un=1
                   ;;
                 Y)
                   un=1
                   ;;
                 n)
                   un=0
                   ;;
                 N)
                   un=0
                   ;;
                 *)
                   "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                   ;;
               esac
               if [ "$un" = 1 ]; then
                   sh "$home_dir/uninstall.sh"
                   exit 0
               fi
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       e)
         clear
         exit 0
       ;;
       E)
         clear
         exit 0
       ;;
       *)
         "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！已经是最后一层了呦，键入 E 退出！\033[0m"
       ;;
     esac
}
######
# 运行函数
while true; do
    md_menu
sleep 0.8
done

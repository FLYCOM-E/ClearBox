#!/system/bin/sh
#此脚本来自ClearBox模块，用于完全卸载模块并清理残留
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 还原模块设置并执行卸载
function uninstall_md()
{
if cat "$work_dir/settings.prop" | grep "stopinstall=1"; then
    sed -i 's/stopinstall=1/stopinstall=0/g' "$work_dir/settings.prop"
elif cat "$work_dir/settings.prop" | grep "stopcache=1"; then
    sed -i 's/stopcache=1/stopcache=0/g' "$work_dir/settings.prop"
elif cat "$work_dir/settings.prop" | grep "clearall=1"; then
    sed -i 's/clearall=1/clearall=0/g' "$work_dir/settings.prop"
fi
sh "$home_dir/service.sh" &
sh "$home_dir/stop-cache/all.done.sh" &
wait
}
######
# 运行卸载函数并卸载软件
uninstall_md
rm -r "$work_dir"
touch "$home_dir/remove"
echo " 3秒后卸载软件！"
echo " 感谢您的使用与支持，欢迎下次光临🙂！！"
sleep 3
pm uninstall "wipe.cache.module"
exit 0

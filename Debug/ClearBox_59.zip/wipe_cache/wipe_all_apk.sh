#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除所有apk文件
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep .*-)
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
"$bin_dir/busybox" find "$dir"/ -type f -name "*.apk" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.APK" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.xapk" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.XAPK" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.apks" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.APKS" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.apkm" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.APKM" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.aab" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.AAB" -delete
######
echo " 内部储存 APK 已清空！"
######
k=""
if [ "$dir2" = "$k" ]; then
    exit 0
fi
######
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.apk" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.APK" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.xapk" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.XAPK" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.apks" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.APKS" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.apkm" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.APKM" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.aab" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.AAB" -delete
######
echo " 外部储存 APK 已清空！"
######
exit 0

#!/system/bin/sh
#此脚本用于提供操作菜单
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

clear
$bin_dir/busybox echo -e "\033[1;34m

        欢迎使用 WIPE-CACHE 操作菜单
 ============================================
  
     1：一键清除所有垃圾
  
     2：清除/cache分区内容
    
     3：清除垃圾文件及空文件夹
     
     4：清除所有APK安装包
     
     5：清除所有压缩包文件
  
     6：清除 dalvik-cache（安卓虚拟机缓存）
    
     7：阻止所有软件更新 / 安装
     
     8：阻止缓存生成功能
     
     00：模块管理

                        --- 键入 E 退出 ---
 ============================================
   
 请输入相应序号：\033[0m"
   read in_put
     case $in_put in
       1)
         clear
         sh $home_dir/all.sh
         $bin_dir/busybox echo -e "\033[1;32m 完成！\033[0m"
         ;;
       2)
         rm -rf /cache/*
         $bin_dir/busybox echo -e "\033[1;32m cache分区已清空！\033[0m"
         ;;
       3)
         clear
         sh $home_dir/wipe_cache/wipe_all_dir.sh
         $bin_dir/busybox echo -e "\033[1;32m sdcard垃圾删除完成！\033[0m"
         ;;
       4)
         sh $home_dir/wipe_cache/wipe_all_apk.sh
         $bin_dir/busybox echo -e "\033[1;32m APK已清空！\033[0m"
         ;;
       5)
         sh $home_dir/wipe_cache/wipe_all_zip.sh
         $bin_dir/busybox echo -e "\033[1;32m 压缩包已清空！\033[0m"
         ;;
       6)
         rm -rf /data/dalvik-cache/*
         $bin_dir/busybox echo -e "\033[1;32m 虚拟机缓存已清空！\033[0m"
         ;;
       7)
         clear
         $bin_dir/busybox echo -e "\033[1;34m
        APP更新安装管理 (beta！！)
 ============================================

     1：阻止APP更新安装
    
     2：关闭阻止更新安装

 ============================================

 请输入相应序号：\033[0m"
         read put1
           case $put1 in
             1)
               chmod 551 /data/app
               $bin_dir/busybox echo -e "\033[1;32m 已开启阻止更新 \033[0m"
               touch $work_dir/S_stop_upapp
               ;;
             2)
               chmod 771 /data/app
               $bin_dir/busybox echo -e "\033[1;31m 已关闭阻止更新 \033[0m"
               rm $work_dir/S_stop_upapp
               ;;
           esac
           ;;
       8)
         clear
         $bin_dir/busybox echo -e "\033[1;34m  
               高级菜单
 ============================================
        自行承担一切风险 | 数据无价
           
     1：开启阻止生成缓存功能「重启生效」
  
     2：关闭阻止生成缓存功能「重启生效」
    
     3：检测开启关闭状态
  
 ============================================

 请输入相应序号：\033[0m"
         read put2
           case $put2 in
             1)
               mkdir -p $work_dir
               touch $work_dir/S_stop_cache
               touch $work_dir/"再见缓存模块配置目录"
               $bin_dir/busybox echo -e "\033[1;32m 已开启，重启生效 ~ \033[0m"
               ;;
             2)
               touch $work_dir/log
               $bin_dir/busybox echo -e "\033[1;31m 已关闭，重启生效 ~ \033[0m"
               ;;
             3)
               if [ -f "$work_dir/S_stop_cache" ]; then
                   $bin_dir/busybox echo -e "\033[1;32m 阻止缓存处于开启状态 \033[0m"
               else
                   $bin_dir/busybox echo -e "\033[1;31m 阻止缓存处于关闭状态 \033[0m"
               fi
               ;;
             *)
               $bin_dir/busybox echo -e "\033[1;31m 输入错误！！\033[0m"
               ;;
           esac
           ;;
       00)
         clear
         $bin_dir/busybox echo -e "\033[1;34m
        模块管理菜单
 ============================================

     1：立即生效模块所有配置
     
     2：定时执行清理任务
     
     3：卸载模块(！

 ============================================

 请输入相应序号：\033[0m"
         read put3
           case $put3 in
             1)
               sh $home_dir/service.sh
               ;;
             2)
               clear
               $bin_dir/busybox echo -e "\033[1;34m
        设定时间
 ============================================

      1：每隔 3 天执行清理垃圾任务
      
      2：每隔 7 天执行清理垃圾任务
      
      3：关闭定时清理
 
 ============================================

 请输入相应序号：\033[0m"
               read put4
                 case $put4 in
                   1)
                     $bin_dir/busybox echo "0 0 */3 * * sh $home_dir/all.sh" > $home_dir/CRON/root
                     ;;
                   2)
                     $bin_dir/busybox echo "0 0 */7 * * sh $home_dir/all.sh" > $home_dir/CRON/root
                     ;;
                   3)
                     $bin_dir/busybox echo "" > $home_dir/CRON/root
                     $bin_dir/busybox echo -e "\033[1;31m 已关闭定时清理！\033[0m"
                     ;;
                 esac
                 ;;
             3)
               echo " 是否卸载模块？y/n"
               read unput
               case $unput in
                 y)
                   un=1
                   ;;
                 Y)
                   un=1
                   ;;
                 n)
                   un=0
                   ;;
                 N)
                   un=0
                   ;;
                 *)
                   $bin_dir/busybox echo -e "\033[1;31m 输入错误！！\033[0m"
                   ;;
               esac
               if [ $un = 1 ]; then
                   sh $home_dir/uninstall.sh
                   exit 0
               fi
               ;;
             *)
               $bin_dir/busybox echo -e "\033[1;31m 输入错误！！\033[0m"
               ;;
           esac
           ;;
       e)
         exit 0
       ;;
       E)
         exit 0
       ;;
       *)
         $bin_dir/busybox echo -e "\033[1;31m 输入错误！！\033[0m"
       ;;
     esac
sleep 1.2
sh $home_dir/wipe-cache_menu.sh


#!/system/bin/sh
#此脚本用于删除所有压缩文件
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep -)
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log
$bin_dir/busybox find $dir/ -type f -name "*.zip" -delete
$bin_dir/busybox find $dir/ -type f -name "*.tar" -delete
$bin_dir/busybox find $dir/ -type f -name "*.7z" -delete
$bin_dir/busybox find $dir/ -type f -name "*.gzip" -delete
$bin_dir/busybox find $dir/ -type f -name "*.bz2" -delete

$bin_dir/busybox find $dir2/ -type f -name "*.zip" -delete
$bin_dir/busybox find $dir2/ -type f -name "*.tar" -delete
$bin_dir/busybox find $dir2/ -type f -name "*.7z" -delete
$bin_dir/busybox find $dir2/ -type f -name "*.gzip" -delete
$bin_dir/busybox find $dir2/ -type f -name "*.bz2" -delete

echo "-- 压缩包已清空！"
exit 0

#!/system/bin/sh
#此脚本用于判断 blacklist.txt 是否存在及放置，并启动阻止缓存脚本
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

mkdir -p $work_dir

if [ ! -f $work_dir/blacklist.txt ]; then
    touch $work_dir/blacklist.txt
fi

echo "正在设置中..."
   sh $home_dir/stop-cache/stop_usercache.sh &
   sh $home_dir/stop-cache/stop_usercache2.sh &
   sh $home_dir/stop-cache/stop_micro-cache.sh &
   sh $home_dir/stop-cache/stop_micro-cache2.sh &
   wait
echo "完成！"

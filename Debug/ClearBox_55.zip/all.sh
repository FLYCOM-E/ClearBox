#!/system/bin/sh
#此脚本来自ClearBox模块，用于运行清理脚本
MODDIR=${0%/*}
cd "$MODDIR"
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
function clear_cache()
{
sh "$home_dir/wipe_cache/data_cache.sh" &
sh "$home_dir/wipe_cache/data_cache2.sh" &
sh "$home_dir/wipe_cache/micro_cache.sh" &
sh "$home_dir/wipe_cache/micro_cache2.sh" &
}
######
function clear_dir()
{
sh "$home_dir/wipe_cache/wipe_list_dir.sh" &
sh "$home_dir/wipe_cache/wipe_all_dir.sh" &
wait
}
######
function clear_tar()
{
if cat "$work_dir/settings.prop" | grep "clearall=1" >/dev/null; then
    sh "$home_dir/wipe_cache/wipe_all_apk.sh" &
    sh "$home_dir/wipe_cache/wipe_all_zip.sh" &
    wait
fi
}
######
function file_all()
{
sh "$home_dir/wipe_cache/file_1.sh" &
sh "$home_dir/wipe_cache/file_2.sh" &
wait
}
######
function f2fs_GC()
{
echo " 磁盘优化已开始，可能需要一点时间，请您耐心等待，可以离开前台"
sm idle-maint run
}
######
case $1 in
    ClearAll)
        clear_cache
        clear_dir
        clear_tar
        file_all
        f2fs_GC
        ;;
    ClearCache)
        clear_cache
        ;;
    ClearTar)
        clear_tar
        ;;
    F2fsGC)
        f2fs_GC
        ;;
esac

echo " 上次优化清理：$(date)" >> "$work_dir/运行日志.log"
echo " 完成！"

#!/system/bin/sh
#此脚本来自ClearBox模块，用于启动运行阻止缓存脚本
MODDIR=${0%/*}
cd "$MODDIR"
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
mkdir -p "$work_dir"
######
if [ ! -f "$work_dir/blacklist.prop" ]; then
    touch "$work_dir/blacklist.prop"
fi
if [ ! -f "$work_dir/whitelist.prop" ]; then
    touch "$work_dir/whitelist.prop"
fi
######
dumpsys window | grep mCurrentFocus | "$bin_dir/busybox" awk -F 'u0 |/' '{print $2}' > "$work_dir/blacklist.prop"
######
if cat "$work_dir/settings.prop" | grep "stopcache=0" >/dev/null; then
    echo "#" > "$work_dir/blacklist.prop"
fi
######
echo " 正在设置中..."
   sh "$home_dir/stop-cache/stop_usercache.sh" &
   sh "$home_dir/stop-cache/stop_micro-cache.sh" &
   wait
echo " 完成！"

#!/system/bin/sh
#此脚本来自ClearBox模块，用于设置SD拓展卡应用阻止缓存
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
in_dir=$(ls /mnt/expand)
Appdir="/mnt/expand/$in_dir/user/0"
Appdir2="/mnt/expand/$in_dir/user_de/0"
blacklist="$work_dir/blacklist.prop"
whitelist="$work_dir/whitelist.prop"
######
k=""
if [ "$in_dir" = "$k" ]; then
    exit 0
fi
######
ls $Appdir | while read dir; do
    if grep "$dir" "$whitelist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    elif ! grep "$dir" "$blacklist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    elif grep "$dir" "$blacklist" >/dev/null; then
        rm -r "$Appdir"/"$dir"/cache/*
        rm -r "$Appdir2"/"$dir"/cache/*
        rm -r "$Appdir"/"$dir"/code_cache/*
        rm -r "$Appdir2"/"$dir"/code_cache/*
        chmod 2551 "$Appdir"/"$dir"/cache
        chmod 2551 "$Appdir2"/"$dir"/cache
        chmod 2551 "$Appdir"/"$dir"/code_cache
        chmod 2551 "$Appdir2"/"$dir"/code_cache
    fi
done

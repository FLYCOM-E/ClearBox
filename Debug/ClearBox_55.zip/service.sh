#!/system/bin/sh
#此脚本来自ClearBox模块，用于完成模块初始及设置
MODDIR=${0%/*}
cd "$MODDIR"
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
function StartSettings()
{
mkdir -p "$work_dir"
touch "$work_dir/settings.prop"
touch "$work_dir/ClearBox模块配置目录"

if ! cat "$work_dir/settings.prop" | grep "stopcache=" >/dev/null; then
    echo "# 阻止缓存" >> "$work_dir/settings.prop"
    echo "stopcache=0" >> "$work_dir/settings.prop"
fi
if ! cat "$work_dir/settings.prop" | grep "stopinstall=" >/dev/null; then
    echo "# 阻止安装/更新" >> "$work_dir/settings.prop"
    echo "stopinstall=0" >> "$work_dir/settings.prop"
fi
if ! cat "$work_dir/settings.prop" | grep "clearall=" >/dev/null; then
    echo "# 是否在一键及定时自动清理时包括安装、压缩包？" >> "$work_dir/settings.prop"
    echo "clearall=0" >> "$work_dir/settings.prop"
fi
}
######
while true; do
    if [ $(getprop sys.boot_completed) = "1" ]; then
        break
    fi
sleep 3
done
######
if [ ! -f "$work_dir/settings.prop" ]; then
    StartSettings
fi
######
echo " 上次开机重置：$(date)" > "$work_dir/运行日志.log"
######
if cat "$work_dir/settings.prop" | grep "stopinstall=1" >/dev/null; then
    chmod 551 /data/app
elif cat "$work_dir/settings.prop" | grep "stopinstall=0" >/dev/null; then
    chmod 771 /data/app
fi
######
if cat "$work_dir/settings.prop" | grep "stopcache=1" >/dev/null; then
    "$bin_dir/busybox" crond -c "$home_dir"/stop-cache/CRON
fi
######
if [ -f "$work_dir/root_backup" ]; then
    cp "$work_dir/root_backup" "$home_dir/CRON/root"
fi
cp "$home_dir/CRON/root" "$work_dir/root_backup"
######
"$bin_dir/busybox" crond -c "$home_dir"/CRON
######
if [ ! -f "$work_dir/list_dir.prop" ]; then
    touch "$work_dir/list_dir.prop"
fi
######
exit 0

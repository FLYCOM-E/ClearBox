#!/system/bin/sh
#此脚本来自ClearBox模块，用于清理自定义清理目录
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
if [ ! -f "$work_dir/list_dir.prop" ]; then
    touch "$work_dir/list_dir.prop"
fi
######
k=""
y=$(cat "$work_dir/list_dir.prop")
if [ "$y" = "$k" ]; then
    echo " 目录为空！请填写自定义清理目录！"
    echo " 目录配置文件位于"$work_dir"/list_dir.prop"
    exit 0
fi
######
for i in $(cat "$work_dir/list_dir.prop"); do
    if echo "$i" | grep "#" >/dev/null; then
        continue
    fi
    echo " 正在清理 $i"
    rm -r "$i"
done
echo " 自定义目录清理完成！"
exit 0

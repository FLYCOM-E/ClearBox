#!/system/bin/sh
#此脚本来自ClearBox模块，用于外部储存user软件缓存清除
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
in_dir=$(ls /mnt/expand)
k=""
if [ "$in_dir" = "$k" ]; then
    exit 0
fi
######
for microcache in $(ls /mnt/expand/*/user/0); do
    rm -r /mnt/expand/*/user/0/"$microcache"/cache/*
    rm -r /mnt/expand/*/user/0/"$microcache"/code_cache/*
    echo " $microcache 缓存已清除"
done
echo " -- micro-user 缓存删除完成"

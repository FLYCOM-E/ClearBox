#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除所有压缩文件
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep .*-)
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
"$bin_dir/busybox" find "$dir"/ -type f -name "*.zip" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.ZIP" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.tar" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.TAR" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.7z" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.7Z" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.gzip" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.GZIP" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.bz2" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.BZ2" -delete
######
k=""
if [ "$dir2" = "$k" ]; then
    echo " 压缩包已清空！"
    exit 0
fi
######
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.zip" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.ZIP" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.tar" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.TAR" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.7z" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.7Z" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.gzip" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.GZIP" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.bz2" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.BZ2" -delete
######
echo " 压缩包已清空！"
exit 0

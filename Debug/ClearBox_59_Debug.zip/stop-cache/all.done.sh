#!/system/bin/sh
#此脚本来自ClearBox模块，用于启动运行阻止缓存脚本
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
# 提取前台软件包名
NowPackageName=$(dumpsys window | grep mCurrentFocus | "$bin_dir/busybox" awk -F 'u0 |/' '{print $2}')
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 创建配置文件，对旧版本配置进行迁移
if [ ! -f "$work_dir/RunStart" ]; then
    touch "$work_dir/RunStart"
elif [ ! -f "$work_dir/whitelist.prop" ]; then
    touch "$work_dir/whitelist.prop"
elif [ -f "$work_dir/blacklist.prop" ]; then
    rm "$work_dir/blacklist.prop"
fi
######
# 检查阻止缓存功能状态，如关闭则清空配置文件使重置权限
# 本来打算检测屏幕是否开启做对应触发，但发现设备兼容太差（各家魔改）
# 现在这样也可以少些判断了(・∀・)
if cat "$work_dir/settings.prop" | grep "stopcache=0" >/dev/null; then
    echo "#" > "$work_dir/RunStart"
elif echo "$NowPackageName" | grep "com.android" >/dev/null; then
    echo "#" > "$work_dir/RunStart"
    exit 0
elif echo "$NowPackageName" | grep "StatusBar" >/dev/null; then
    echo "#" > "$work_dir/RunStart"
    exit 0
else
    echo "$NowPackageName" > "$work_dir/RunStart"
fi
######
sh "$home_dir/stop-cache/stop_usercache.sh" &
sh "$home_dir/stop-cache/stop_micro-cache.sh" &
wait

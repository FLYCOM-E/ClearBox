#!/system/bin/sh
#此脚本来自ClearBox模块，用于设置SD拓展卡应用阻止缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
in_dir=$(ls /mnt/expand)
Appdir="/mnt/expand/$in_dir/user/0"
Appdir2="/mnt/expand/$in_dir/user_de/0"
blacklist="$work_dir/RunStart"
whitelist="$work_dir/whitelist.prop"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# sd拖着卡是否存在做额外检测
k=""
if [ "$in_dir" = "$k" ]; then
    exit 0
fi
######
ls "$Appdir" | while read dir; do
    # 如果检测到 “com.android.xxx” 的系统核心软件则返回
    if echo "$dir" | grep "com.android" >dev/null; then
        continue
    # 如果该包名位于白名单则重置权限并返回，不属于前台软件同理
    elif grep "$dir" "$whitelist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    elif ! grep "$dir" "$blacklist" >/dev/null; then
        chmod 2771 "$Appdir"/"$dir"/cache
        chmod 2771 "$Appdir2"/"$dir"/cache
        chmod 2771 "$Appdir"/"$dir"/code_cache
        chmod 2771 "$Appdir2"/"$dir"/code_cache
        continue
    # 位于前台则启用阻止缓存
    elif grep "$dir" "$blacklist" >/dev/null; then
        rm -r "$Appdir"/"$dir"/cache/*
        rm -r "$Appdir2"/"$dir"/cache/*
        rm -r "$Appdir"/"$dir"/code_cache/*
        rm -r "$Appdir2"/"$dir"/code_cache/*
        chmod 2551 "$Appdir"/"$dir"/cache
        chmod 2551 "$Appdir2"/"$dir"/cache
        chmod 2551 "$Appdir"/"$dir"/code_cache
        chmod 2551 "$Appdir2"/"$dir"/code_cache
    fi
done

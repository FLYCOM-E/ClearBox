#!/system/bin/sh
#此脚本来自ClearBox模块，用于自定义清理/干掉文件目录
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! $(echo -e "clearbox -v") >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
if [ ! -f "$work_dir/list_dir.prop" ]; then
    touch "$work_dir/list_dir.prop"
fi
######
# 检查配置文件
k=""
y=$(cat "$work_dir/list_dir.prop")
if [ "$y" = "$k" ]; then
    echo " 配置为空！请填写自定义处理路径！"
    echo " 路径配置文件位于"$work_dir"/list_dir.prop"
    exit 0
fi
######
for i in $(cat "$work_dir/list_dir.prop"); do
    df=$(echo "$i" | "$bin_dir/busybox" awk -F "=" '{print $2}')
    # 如果该行被注释则返回
    if echo "$i" | grep ^"#" >/dev/null; then
        continue
    fi
    # 设置clear参数则删除该文件夹
    if echo "$i" | grep "CLEAR" >/dev/null; then
        echo " 正在清空 $df"
        rm -r "$df"
    # 设置kill参数则将对应文件夹替换为文件
    elif echo "$i" | grep "KILL" >/dev/null; then
        if [ -d "$df" ]; then
            echo " 正在干掉 $df"
            rm -r "$df"
            touch "$df"
        else
            echo " 干掉 $df 失败：不是一个目录"
        fi
    fi
done
######
prints 0.1@" 自定义目录处理完成！"
exit 0

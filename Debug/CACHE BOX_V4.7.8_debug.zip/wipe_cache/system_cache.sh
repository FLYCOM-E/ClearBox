#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"

rm -rf /cache/*
rm -rf /data/dalvik-cache/*
rm -rf /data/system/package_cache/*

echo " 系统缓存已清空！建议立即重启！"
exit 0

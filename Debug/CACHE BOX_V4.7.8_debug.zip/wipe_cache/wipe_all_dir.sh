#!/system/bin/sh
#此脚本用于删除垃圾缓存及空文件夹
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep -)
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"
for c in $(ls "$dir"/Android/data); do
    rm -rf "$dir"/Android/data/"$c"/cache/*
    [[ $? -eq 0 ]] && echo "$c 缓存已清除"
done
rm -r "$dir"/Pictures/.thumbnails
rm -r "$dir"/Movies/.thumbnails
rm -r "$dir"/music/.thumbnails
rm -r "$dir"/DCIM/.thumbnails
"$bin_dir/busybox" find "$dir" -type d -empty -delete
if [ ! "$dir2" = "" ]; then
    for v in $(ls "$dir2"/Android/data); do
        rm -rf "$F"/Android/data/"$v"/cache/*
    [[ $? -eq 0 ]] && echo "$v 缓存已清除"
    done
    rm -rf "$dir2"/Pictures/.thumbnails
    rm -rf "$dir2"/Movies/.thumbnails
    rm -rf "$dir2"/music/.thumbnails
    rm -rf "$dir2"/DCIM/.thumbnails
    "$bin_dir/busybox" find "$dir2" -type d -empty -delete
fi
echo "sdcard垃圾删除完成！"
exit 0

#!/system/bin/sh
#此脚本用于删除自定义垃圾目录
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>"$home_dir/LOG.log"

if [ ! -f "$work_dir/list_dir.txt" ]; then
    touch "$work_dir/list_dir.txt"
fi

k=""
if [ $(cat "$work_dir/list_dir.txt") = "$k" ]; then
    echo "目录为空！请填写自定义清理目录！"
    exit 0
fi

for i in $(cat "$work_dir/list_dir.txt"); do
    if echo "$i" | grep "#" >/dev/null; then
        continue
    fi
    echo "正在清理 $i"
    rm -rf "$i"
done
echo " 自定义目录清理完成！"
exit 0

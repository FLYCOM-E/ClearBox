#!/system/bin/sh
exec 2>/dev/null
#阻止安装处于开启状态则临时关闭
if [ -f /data/adb/wipe_cache/S_stop_upapp ]; then
    chmod 771 /data/app
    sa=1
else
    sa=0
fi

if [ -d /data/adb/magisk ]; then
    echo "               "
    echo " 您正在使用 Magisk ROOT 🔥"
elif [ -d /data/adb/ap ]; then
    echo "               "
    echo " 您正在使用 Apatch ROOT 🔥"
elif [ -d /data/adb/ksu ]; then
    echo "               "
    echo " 您正在使用 KernelSU ROOT 🔥"
else
    echo "               "
    echo " 未检测到适配的 ROOT 方案 ❄"
    echo " 如果运行异常请联系模块作者适配！"
fi

#检查为安装/更新
if [ -d /data/data/wipe.cache.module ]; then
    echo "               "
    echo " 是否更新模块 CACHE BOX 软件？"
    echo "               "
    echo " 按下音量上键更新，触摸屏幕或任意按键取消 &&"
    echo "               "
else
    echo "               "
    echo " 是否安装模块 WIPE-CACHE 软件？"
    echo "               "
    echo " 按下音量上键安装，触摸屏幕或任意按键取消 &&          "
    echo "               "
fi
#开始安装程序
getevent -qlc 1 2>> /dev/null | while read -r A; do
  case "$A" in
    *KEY_VOLUMEUP*)
      echo " 正在为您安装 CACHE BOX 软件❤"
      cp "$MODPATH"/system/*CACHE*.apk "$TMPDIR"/
      chmod 777 "$TMPDIR"/*CACHE*.apk
      if pm install -r "$TMPDIR"/*CACHE*.apk; then
          echo "               "
          echo " 安装成功！✅"
          rm "$TMPDIR"/*CACHE*.apk
      else
          echo "               "
          echo " 安装失败！❌"
          DE=1
          if [ "$DE" = 1 ]; then
              echo "               "
              echo " 检测到方法一安装失败，是否尝试以第二方式安装？"
              echo "               "
              echo " 按下音量上键确认，触摸屏幕或任意按键取消"
              
              getevent -qlc 1 2>> /dev/null | while read -r A; do
                case "$A" in
                  *KEY_VOLUMEUP*)
                    echo "               "
                    echo " 正在尝试安装！"
                    pm uninstall "wipe.cache.module"
                    wait
                    if pm install -r "$TMPDIR"/*CACHE*.apk; then
                        echo "               "
                        echo " 安装成功！✅"
                        rm "$TMPDIR"/*CACHE*.apk
                    else
                        echo "               "
                        echo " 安装失败！❌"
                        echo "               "
                        echo " 请反馈开发或手动安装！"
                        D=1
                    fi
                    ;;
                  *)
                    echo " 已为您取消安装💔"
                    ;;
                esac
              done
          fi
      fi
      ;;
    *)
      echo " 已为您取消安装💔"
      ;;
  esac
done
#还原阻止安装
if [ "$sa" = 1 ]; then
    chmod 551 /data/app
fi
echo "                                       "
echo " 感谢您的使用！您的支持是我最大的动力！！🎉🎉🎉"
echo "                                       "
echo " 模块安装完成 ✨"

#!/system/bin/sh
#文件收集归类
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir2=/storage/$(ls /storage | grep -)
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2> /dev/null

mkdir -p "$dir2/Documents/压缩包"
zip_dir="$dir2/Documents/压缩包"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.zip") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.ZIP") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.tar") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.TAR") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.7z") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.7Z") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.gzip") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.GZIP") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.bz2") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.BZ2") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.rar") "$zip_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.RAR") "$zip_dir"

mkdir -p "$dir2/Documents/安装包"
apk_dir="$dir2/Documents/安装包"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.apk") "$apk_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.APK") "$apk_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.xapk") "$apk_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.XAPK") "$apk_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.apks") "$apk_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.APKS") "$apk_dir"

mkdir -p "$dir2/Documents/镜像文件"
img_dir="$dir2/Documents/镜像文件"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.img") "$img_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.IMG") "$img_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.iso") "$img_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.ISO") "$img_dir"

mkdir -p "$dir2/Documents/字体文件"
font_dir="$dir2/Documents/字体文件"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.ttf") "$font_dir"
mv $($bin_dir/busybox find "$dir2"/ -type f -name "*.TTF") "$font_dir"

exit 0
#!/system/bin/sh
#此脚本用于删除垃圾缓存及空文件夹
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep -)
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

sh $home_dir/wipe_cache/file_1.sh &
sh $home_dir/wipe_cache/file_2.sh &
wait

echo "文件已集中，位置/sdcard/Documents分类文件夹内！"
sleep 1
exit 0
#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log
sh $home_dir/wipe_cache/data_cache.sh &
sh $home_dir/wipe_cache/data_cache2.sh &
sh $home_dir/wipe_cache/micro_cache.sh &
sh $home_dir/wipe_cache/micro_cache2.sh &
sh $home_dir/wipe_cache/wipe_all_apk.sh &
sh $home_dir/wipe_cache/wipe_all_dir.sh &
sh $home_dir/wipe_cache/wipe_all_zip.sh &
wait

echo " 上次清理时间：$(date)" >> $work_dir/运行日志.log
echo "All Ok！"

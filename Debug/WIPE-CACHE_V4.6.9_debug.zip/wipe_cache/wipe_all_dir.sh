#!/system/bin/sh
#此脚本用于删除/sdcard内缓存及空文件夹

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

ls /storage/emulated/0/Android/data/ | while read c; do
    rm -rf /storage/emulated/0/Android/data/$c/cache/*
    rm -rf /storage/emulated/0/Pictures/.thumbnails/*
    rm -rf /storage/emulated/0/Movies/.thumbnails/*
    rm -rf /storage/emulated/0/music/.thumbnails/*
    rm -rf /storage/emulated/0/Music/.thumbnails/*
    [[ $? -eq 0 ]] && echo "$c 缓存已清除"
done

cd /storage/emulated/0/
$bin_dir/busybox find . -type d -empty -delete

echo "-- /sdcard 空文件夹及垃圾清理完成！"
exit 0

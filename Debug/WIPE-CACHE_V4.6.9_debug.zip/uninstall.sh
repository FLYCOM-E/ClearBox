#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)

if [ -f $work_dir/S_stop_upapp ]; then
    chmod 771 /data/app
fi

mkdir $work_dir/log
echo "" > $work_dir/blacklist.txt
sh $home_dir/service.sh
wait

rm -r $work_dir
echo " 3秒后卸载软件！"
echo " 感谢您的使用与支持，欢迎下次光临！！"
sleep 3
touch $home_dir/remove
pm uninstall "wipe.cache.module"

exit 0

#!/system/bin/sh
#此脚本来自ClearBox模块，用于完全卸载模块并清理残留
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 还原模块设置并执行卸载
function uninstall_md()
{
sed -E -i 's/(stopinstall|stopcache|clearall|fileall|cleardisk)=1/\1=0/g' "$work_dir/settings.prop"
sh "$home_dir/service.sh" &
sh "$home_dir/StopCache" Reset &
wait
touch "$home_dir/disable"
touch "$home_dir/remove"
}
######
# 运行卸载函数并卸载软件
uninstall_md
rm -r "$work_dir"
echo " 3秒后卸载软件！"
echo " 感谢您的使用与支持，欢迎下次光临🙂！！"
sleep 3
pm uninstall "wipe.cache.module"
exit 0

#!/system/bin/sh
#此脚本来自ClearBox模块，用于完成模块初始 & 设置 & 加载
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
function StartSettings()
{
mkdir -p "$work_dir"
touch "$work_dir/settings.prop"
touch "$work_dir/ClearBox模块配置目录"
if ! grep ^"stopcache=" "$work_dir/settings.prop" >/dev/null; then
    echo "stopcache=0" >> "$work_dir/settings.prop"
fi
if ! grep ^"stopinstall=" "$work_dir/settings.prop" >/dev/null; then
    echo "stopinstall=0" >> "$work_dir/settings.prop"
fi
if ! grep ^"clearall=" "$work_dir/settings.prop" >/dev/null; then
    echo "clearall=0" >> "$work_dir/settings.prop"
fi
if ! grep ^"fileall=" "$work_dir/settings.prop" >/dev/null; then
    echo "fileall=0" >> "$work_dir/settings.prop"
fi
if ! grep ^"cleardisk=" "$work_dir/settings.prop" >/dev/null; then
    echo "cleardisk=1" >> "$work_dir/settings.prop"
fi
if [ ! -f "$work_dir/whitelist.prop" ]; then
    touch "$work_dir/whitelist.prop"
fi
if [ ! -f "$work_dir/ClearWhitelist.prop" ]; then
    touch "$work_dir/ClearWhitelist.prop"
fi
}
######
while true; do
    if [ "$(getprop sys.boot_completed)" = 1 >/dev/null ]; then
        break
    fi
sleep 3
done
######
StartSettings
echo "[ $(date) ] ###  ReStart  ###" > "$work_dir/运行日志.log"
######
if grep "stopinstall=1" "$work_dir/settings.prop" >/dev/null; then
    chmod 551 /data/app
elif grep "stopinstall=0" "$work_dir/settings.prop" >/dev/null; then
    chmod 771 /data/app
fi
######
if grep "stopcache=1" "$work_dir/settings.prop" >/dev/null; then
    echo -n "* * * * * sh '$home_dir/StopCache' Stop" > "$home_dir/CRON/StopCache/root"
    echo "[ $(date) ]：阻止缓存运行" >> "$work_dir/运行日志.log"
else
    echo -n "" > "$home_dir/CRON/StopCache/root"
fi
"$bin_dir/busybox" crond -c "$home_dir"/CRON/StopCache
######
if ! grep "sh" "$home_dir/CRON/ClearCache/root" >/dev/null; then
    if grep "sh" "$work_dir/root_backup" >/dev/null; then
        cp "$work_dir/root_backup" "$home_dir/CRON/ClearCache/root"
    fi
fi
"$bin_dir/busybox" crond -c "$home_dir"/CRON/ClearCache
######
exit 0

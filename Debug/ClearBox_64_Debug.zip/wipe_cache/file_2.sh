#!/system/bin/sh
#此脚本来自ClearBox模块，用于外部储存文件收集归类
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$work_dir/运行日志.log"
dir=/storage/$(ls /storage | grep .*-)
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
if ! ls /storage | grep .*- >/dev/null; then
    exit 0
fi
if grep "cleardisk=0" "$work_dir/settings.prop" >/dev/null; then
    exit 0
fi
######
function tar_file()
{
mkdir -p "$dir/Documents/压缩包"
zip_dir="$dir/Documents/压缩包"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.zip") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.ZIP") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.tar") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.TAR") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.7z") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.7Z") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.gz") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.GZ") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.bz2") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.BZ2") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.rar") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.RAR") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.lz4") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.LZ4") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.zst") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.ZST") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.xz") "$zip_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.XZ") "$zip_dir"
echo " 外部储存压缩包归类完成！"
}
######
function apk_file()
{
mkdir -p "$dir/Documents/安装包"
apk_dir="$dir/Documents/安装包"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.apk") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.APK") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.xapk") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.XAPK") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.apks") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.APKS") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.apkm") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.APKM") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.aab") "$apk_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.AAB") "$apk_dir"
echo " 外部储存安装包归类完成！"
}
######
function iso_file()
{
mkdir -p "$dir/Documents/镜像文件"
img_dir="$dir/Documents/镜像文件"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.img") "$img_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.IMG") "$img_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.iso") "$img_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.ISO") "$img_dir"
echo " 外部储存镜像文件归类完成！"
}
######
function font_file()
{
mkdir -p "$dir/Documents/字体文件"
font_dir="$dir/Documents/字体文件"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.ttf") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.TTF") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.otf") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.OTF") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.woff") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.WOFF") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.woff2") "$font_dir"
mv $("$bin_dir/busybox" find "$dir"/ -type f -name "*.WOFF2") "$font_dir"
echo " 外部储存字体文件归类完成！"
}
######
tar_file &
wait
apk_file &
wait
iso_file &
wait
font_file &
wait
######
exit 0

#!/system/bin/sh
#此脚本来自ClearBox模块，用于清空内部储存软件缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
data_dir1="/data/user"
data_dir2="/data/user_de"
micro_dir1="/mnt/expand/$(ls /mnt/expand)/user"
micro_dir2="/mnt/expand/$(ls /mnt/expand)/user_de"
whitelist="$work_dir/ClearWhitelist.prop"
exec 2>>"$work_dir/运行日志.log"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
function WipeCache1()
{
# 遍历清空内部储存软件cache文件夹
ls "$data_dir1/" | while read userid_dir; do
    for user1cache in $(pm list package -3 | cut -f2 -d ':'); do
        if grep ^"$user1cache" "$whitelist" >/dev/null; then
            continue
        fi
        if [ ! -d "/data/user/$userid_dir/$user1cache" ]; then
            continue
        fi
        rm -r "$data_dir1/$userid_dir/$user1cache/cache/"* &
        rm -r "$data_dir1/$userid_dir/$user1cache/code_cache/"* &
        rm -r "$data_dir2/$userid_dir/$user1cache/cache/"* &
        rm -r "$data_dir2/$userid_dir/$user1cache/code_cache/"* &
        wait
        echo " $user1cache 缓存已清除"
    done
done
echo " -- 内部储存软件缓存删除完成"
}
######
function WipeCache2()
{
if [ ! -d $micro_dir1 ]; then
    exit 0
fi
if grep "cleardisk=0" "$work_dir/settings.prop" >/dev/null; then
    exit 0
fi
######
# 遍历清空软件cache文件夹
ls "$micro_dir1/" | while read userid_dir; do
    for microcache in $(ls "$micro_dir1/$userid_dir"); do
        if grep ^"$microcache" "$whitelist" >/dev/null; then
            continue
        fi
        rm -r "$micro_dir1/$userid_dir/$microcache/cache/"* &
        rm -r "$micro_dir1/$userid_dir/$microcache/code_cache/"* &
        rm -r "$micro_dir2/$userid_dir/$microcache/cache/"* &
        rm -r "$micro_dir2/$userid_dir/$microcache/code_cache/"* &
        wait
        echo " $microcache 缓存已清除"
    done
done
echo " -- 外部储存软件缓存删除完成"
}
######
WipeCache1 &
WipeCache2 &
wait

#!/system/bin/sh
#此脚本来自ClearBox模块，用于清空压缩文件
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$work_dir/运行日志.log"
dir="/storage/emulated/0"
dir2=/storage/$(ls /storage | grep .*-)
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
"$bin_dir/busybox" find "$dir"/ -type f -name "*.zip" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.ZIP" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.tar" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.TAR" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.7z" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.7Z" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.gz" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.GZ" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.bz2" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.BZ2" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.rar" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.RAR" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.lz4" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.LZ4" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.zst" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.ZST" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.xz" -delete
"$bin_dir/busybox" find "$dir"/ -type f -name "*.XZ" -delete
echo " 内部储存压缩包已清空！"
######
if ! ls /storage | grep .*- >/dev/null; then
    exit 0
fi
if grep "cleardisk=0" "$work_dir/settings.prop" >/dev/null; then
    exit 0
fi
######
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.zip" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.ZIP" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.tar" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.TAR" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.7z" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.7Z" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.gz" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.GZ" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.bz2" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.BZ2" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.rar" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.RAR" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.lz4" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.LZ4" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.zst" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.ZST" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.xz" -delete
"$bin_dir/busybox" find "$dir2"/ -type f -name "*.XZ" -delete
echo " 外部储存压缩包已清空！"
######
exit 0

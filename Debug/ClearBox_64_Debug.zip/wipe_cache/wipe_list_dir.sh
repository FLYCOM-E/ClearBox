#!/system/bin/sh
#此脚本来自ClearBox模块，用于自定义规则清理/干掉文件目录
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$work_dir/运行日志.log"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
if [ ! -d "$work_dir/清理配置" ]; then
    mkdir "$work_dir/清理配置"
fi
######
if [ "$(ls "$work_dir/清理配置/")" = "" ]; then
    exit 0
fi
ls "$work_dir/清理配置/" | while read File; do
    Pro_File="$work_dir/清理配置/$File"
    if [ -d "$Pro_File" ]; then
        echo " $Pro_File：未知的目录，已自动清除！"
        rm -r "$Pro_File"
        continue
    elif [ ! -f "$Pro_File" ]; then
        " $Pro_File：配置读取错误，请检查！"
    fi
    if [ "$(cat "$Pro_File")" = "" ]; then
        echo " $Pro_File：配置内容为空！"
        continue
    fi
    ######
    for i in $(cat "$Pro_File"); do
        df=$(echo "$i" | cut -f2 -d '=')
        ######
        # 如果指定初始目录则进入该目录
        if echo "$i" | grep ^"@" >/dev/null; then
            local dir=$(echo "$i" | grep ^"@" | cut -f2 -d '.')
            cd "$dir"
            continue
        fi
        ######
        if echo "$i" | grep ^"/" >/dev/null; then
            echo " $Pro_File：配置存在错误及危险操作，请检查❗❗❗"
            exit 1
        fi
        # 如果该行被注释则返回
        if echo "$i" | grep ^"#" >/dev/null; then
            continue
        fi
        # 设置clear参数则删除该文件夹
        if echo "$i" | grep ^"CLEAR" >/dev/null; then
            echo " 正在清空 $df"
            rm -r "$df/"
        # 设置kill参数则将对应文件夹替换为文件
        elif echo "$i" | grep ^"KILL" >/dev/null; then
            echo " 正在强制干掉 $df"
            if [ -d "$df" ]; then
                rm -r "$df"
            fi
            touch "$df"
        fi
    done
done
######
echo " 自定义目录处理完成！"
exit 0

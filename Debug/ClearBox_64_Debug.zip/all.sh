#!/system/bin/sh
#此脚本来自ClearBox模块，用于根据传入参数调用清理脚本
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$work_dir/运行日志.log"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 避免不必要的问题临时关闭SELinux
if ! setenforce 0; then
    echo " SELinux状态设置失败❗"
fi
######
# 设置函数
function clear_cache()
{
sh "$home_dir/wipe_cache/data_cache.sh" &
wait
echo "[ $(date) ]：清理软件缓存" >> "$work_dir/运行日志.log"
}
######
function clear_scache()
{
sh "$home_dir/wipe_cache/system_cache.sh" &
wait
echo "[ $(date) ]：清除系统缓存" >> "$work_dir/运行日志.log"
}
######
function list_dir()
{
sh "$home_dir/wipe_cache/wipe_list_dir.sh" &
wait
echo "[ $(date) ]：运行干掉目录" >> "$work_dir/运行日志.log"
}
function all_dir()
{
sh "$home_dir/wipe_cache/wipe_all_dir.sh" &
wait
echo "[ $(date) ]：清理内部储存" >> "$work_dir/运行日志.log"
}
######
function dir_file()
{
sh "$home_dir/wipe_cache/wipe_list_dir.sh"
sh "$home_dir/wipe_cache/wipe_all_dir.sh"
echo "[ $(date) ]：运行干掉目录、清理内部储存" >> "$work_dir/运行日志.log"
}
######
function clear_apk()
{
sh "$home_dir/wipe_cache/wipe_all_apk.sh" &
wait
echo "[ $(date) ]：清理安装包" >> "$work_dir/运行日志.log"
}
######
function clear_zip()
{
sh "$home_dir/wipe_cache/wipe_all_zip.sh"
echo "[ $(date) ]：清理压缩包" >> "$work_dir/运行日志.log"
}
######
function clear_tar()
{
if grep "clearall=1" "$work_dir/settings.prop" >/dev/null; then
    sh "$home_dir/wipe_cache/wipe_all_apk.sh"
    sh "$home_dir/wipe_cache/wipe_all_zip.sh"
    echo "[ $(date) ]：清理压缩包及安装包" >> "$work_dir/运行日志.log"
fi
}
######
function file_all()
{
sh "$home_dir/wipe_cache/file_1.sh"
sh "$home_dir/wipe_cache/file_2.sh"
echo "[ $(date) ]：运行文件归类" >> "$work_dir/运行日志.log"
}
function file_all2()
{
if grep "fileall=1" "$work_dir/settings.prop" >/dev/null; then
    sh "$home_dir/wipe_cache/file_1.sh"
    sh "$home_dir/wipe_cache/file_2.sh"
    echo "[ $(date) ]：运行文件归类" >> "$work_dir/运行日志.log"
fi
}
######
function f2fs_GC()
{
sh "$home_dir/wipe_cache/f2fs_GC.sh" &
wait
echo "[ $(date) ]：GC磁盘优化" >> "$work_dir/运行日志.log"
}
######
function f2fs_GC2()
{
echo " 磁盘优化已开始，可能需要一点时间，请您耐心等待，可以离开前台"
if sm idle-maint run >/dev/null; then
    echo " 磁盘优化完成，可以试试更激进的GC优化哦 (・∀・)"
    i="成功"
else
    echo " 您的设备不支持此磁盘优化功能 (・・;"
    i="失败"
fi
echo "[ $(date) ]：快速磁盘优化 <$i>" >> "$work_dir/运行日志.log"
}
######
function freezer()
{
if [ $(device_config put activity_manager_native_boot use_freezer) = "false" ]; then
    device_config put activity_manager_native_boot use_freezer true
    echo " 已打开安卓原生墓碑 (^^)"
fi
}
######
# 根据输入参数执行对应操作
case $1 in
    ClearAll)
        echo "[ $(date) ]：运行一键优化" >> "$work_dir/运行日志.log"
        clear_cache &
        dir_file &
        clear_tar &
        file_all2 &
        wait
        freezer &
        f2fs_GC2 &
        wait
        ;;
    ClearCache)
        clear_cache
        ;;
    Clear_SCache)
        clear_scache
        ;;
    List_Dir)
        list_dir
        ;;
    All_Dir)
        all_dir
        ;;
    Clear_Apk)
        clear_apk
        ;;
    Clear_Zip)
        clear_zip
        ;;
    File_All)
        file_all
        ;;
    F2fs_GC)
        f2fs_GC
        ;;
    Freezer)
        freezer
        ;;
esac
######
# 恢复SELinux
if ! setenforce 1; then
    echo " SELinux状态恢复失败❗"
fi
######
echo " 完成！"

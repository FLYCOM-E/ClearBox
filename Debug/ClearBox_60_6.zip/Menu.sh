#!/system/bin/sh
#此脚本来自ClearBox模块，用于提供终端菜单
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
#exec 2>>"$home_dir/LOG.log"
V=$(cat "$home_dir/module.prop" | grep "version=" | "$bin_dir/busybox" awk -F '=' '{print $2}')
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
echo " 打开终端 UI：$(date)" > "$work_dir/运行日志.log"
######
# 菜单函数
function md_menu()
{
clear
"$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[欢迎使用 ClearBox    "$V"]\033[0m")
 ===================================================

 1：一键优化清理             2：清理干掉自定义目录

 3：清除垃圾文件及空文件夹   4：清空所有软件缓存
     
 5：深度清理                 6：阻止软件更新安装 
    
 7：阻止缓存生成功能         8：磁铁（一键归类文件

 9：磁盘优化（GC）           00：模块管理

 ===================================================
                                --- 键入 E 退出 ---
 请输入相应序号:"
   read in_put
     case "$in_put" in
       1)
         sh "$home_dir/all.sh" ClearAll &
         wait
         ;;
       2)
         sh "$home_dir/wipe_cache/wipe_list_dir.sh" &
         wait
         ;;
       3)
         sh "$home_dir/wipe_cache/wipe_all_dir.sh" &
         wait
         ;;
       4)
         sh "$home_dir/all.sh" ClearCache &
         wait
         ;;
       5)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[深度清理，请备份重要文档！！]\033[0m")
 ===================================================
     
     1：清除所有APK安装包
     
     2：清除所有压缩包文件
     
     3：清空系统缓存

 ===================================================

 请输入相应序号:"
         read put1
           case "$put1" in
             1)
               echo -ne " 确认？(y): "
               read put_1
               case "$put_1" in
                 y | Y)
                   sh "$home_dir/wipe_cache/wipe_all_apk.sh" &
                   wait
                   ;;
                 *)
                   "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                   ;;
               esac
               ;;
             2)
               echo -ne " 确认？(y): "
               read put_11
               case "$put_11" in
                 y | Y)
                   sh "$home_dir/wipe_cache/wipe_all_zip.sh" &
                   wait
                   ;;
                 *)
                   "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                   ;;
               esac
               ;;
             3)
               echo -ne " 确认？(y): "
               read put_2
               case "$put_2" in
                 y | Y)
                   sh "$home_dir/wipe_cache/system_cache.sh" &
                   wait
                   ;;
                 *)
                   "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                   ;;
               esac
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       6)
         clear
         if cat "$work_dir/settings.prop" | grep "stopinstall=1" >/dev/null; then
             i1="关闭"
         else
             i1="开启"
         fi
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[APP更新安装管理]\033[0m")
 ===================================================

     1：$i1阻止APP更新安装

 ===================================================

 请输入相应序号:"
         read put1
           case "$put1" in
             1)
               if [ "$i1" = "开启" ]; then
                   echo -ne " 确认？(y): "
                   read put_3
                   case "$put_3" in
                     y | Y)
                       chmod 551 /data/app
                       prints 0.1@" 已开启阻止更新！"
                       if cat "$work_dir/settings.prop" | grep "stopinstall=0" >/dev/null; then
                           sed -i 's/stopinstall=0/stopinstall=1/g' "$work_dir/settings.prop"
                       fi
                       ;;
                     *)
                       "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                       ;;
                   esac
               else
                   chmod 771 /data/app
                   prints 0.1@" 已关闭阻止更新！"
                   sed -i 's/stopinstall=1/stopinstall=0/g' "$work_dir/settings.prop"
               fi
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       7)
         clear
         if cat "$work_dir/settings.prop" | grep "stopcache=0" >/dev/null; then
             i2="开启"
         else
             i2="关闭"
         fi
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[阻止缓存]\033[0m")
 ===================================================

     1：$i2阻止生成缓存功能
  
 ===================================================

 请输入相应序号:"
         read put2
           case "$put2" in
             1)
               if [ "$i2" = "开启" ]; then
                   echo -ne " 确认？(y): "
                   read put
                   case "$put" in
                     y | Y)
                       if cat "$work_dir/settings.prop" | grep "stopcache=0" >/dev/null; then
                           sed -i 's/stopcache=0/stopcache=1/g' "$work_dir/settings.prop"
                       fi
                       prints 0.1@" 已开启，重启生效 ~"
                       ;;
                   esac
               else
                   sed -i 's/stopcache=1/stopcache=0/g' "$work_dir/settings.prop"
                   prints 0.1@" 已关闭，重启生效 ~"
               fi
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       8)
         echo -ne " 确认？(y): "
         read put_4
         case "$put_4" in
           y | Y)
             sh "$home_dir/all.sh" File_All &
             wait
             ;;
           *)
             "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
             ;;
         esac
         ;;
       9)
         sh "$home_dir/all.sh" F2fs_GC &
         wait
         ;;
       00)
         clear
         "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[模块管理菜单]\033[0m")
 ===================================================

     1：立即生效模块所有配置
     
     2：定期运行优化整理
     
     3：清理设置
     
     00：卸载模块(！

 ===================================================

 请输入相应序号:"
         read put3
           case "$put3" in
             1)
               sh "$home_dir/service.sh" &
               wait
               prints 0.1@" 完成！"
               ;;
             2)
               clear
               "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[设定时间]\033[0m")
 ===================================================
      
      1：每隔 1 天自动运行优化整理
      
      2：每隔 3 天自动运行优化整理
      
      3：每隔 7 天自动运行优化整理
      
      4：每隔 15 天自动运行优化整理
      
      5：每隔 30 天自动运行优化整理
      
      0：关闭定期优化
 
 ===================================================

 请输入相应序号:"
               read put4
                 case "$put4" in
                   1)
                     echo "0 0 */1 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     echo "0 0 */1 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     prints 0.1@" 设定成功！"
                     ;;
                   2)
                     echo "0 0 */3 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     echo "0 0 */3 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     prints 0.1@" 设定成功！"
                     ;;
                   3)
                     echo "0 0 */7 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     echo "0 0 */7 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     prints 0.1@" 设定成功！"
                     ;;
                   4)
                     echo "0 0 */15 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     echo "0 0 */15 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     prints 0.1@" 设定成功！"
                     ;;
                   5)
                     echo "0 0 */30 * * sh $home_dir/all.sh ClearAll" > "$home_dir/CRON/root"
                     echo "0 0 */30 * * sh $home_dir/all.sh ClearAll" > "$work_dir/root_backup"
                     prints 0.1@" 设定成功！"
                     ;;
                   0)
                     echo -n "" > "$home_dir/CRON/root"
                     echo -n "" > "$work_dir/root_backup"
                     prints 0.1@" 已关闭定期优化！"
                     ;;
                   *)
                     "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                     ;;
                 esac
                 ;;
             3)
               clear
               if cat "$work_dir/settings.prop" | grep "clearall=0" >/dev/null; then
                   i3="开启"
               else
                   i3="关闭"
               fi
               if cat "$work_dir/settings.prop" | grep "fileall=0" >/dev/null; then
                   i4="开启"
               else
                   i4="关闭"
               fi
               "$bin_dir/busybox" echo -ne "
$(echo -e "\033[46m[清理设置]\033[0m")
 ===================================================

     1：$i3一键及定时自动清理时包括安装、压缩包

     2：$i4一键及定时自动清理时运行文件归类功能
     
 ===================================================

 请输入相应序号:"
               read put5
                 case "$put5" in
                   1)
                     if [ "$i3" = "开启" ]; then
                         echo -ne " 确认？(y): "
                         read put_5
                         case "$put_5" in
                           y | Y)
                             if cat "$work_dir/settings.prop" | grep "clearall=0" >/dev/null; then
                                 sed -i 's/clearall=0/clearall=1/g' "$work_dir/settings.prop"
                                 prints 0.1@" 已开启！"
                             fi
                             ;;
                         esac
                     else
                         sed -i 's/clearall=1/clearall=0/g' "$work_dir/settings.prop"
                         prints 0.1@" 已关闭！"
                     fi
                     ;;
                   2)
                     if [ "$i4" = "开启" ]; then
                         echo -ne " 确认？(y): "
                         read put_6
                         case "$put_6" in
                           y | Y)
                             sed -i 's/fileall=0/fileall=1/g' "$work_dir/settings.prop"
                             prints 0.1@" 已开启！"
                             ;;
                         esac
                     else
                         sed -i 's/fileall=1/fileall=0/g' "$work_dir/settings.prop"
                         prints 0.1@" 已关闭！"
                     fi
                     ;;
                   *)
                     "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                     ;;
                 esac
                 ;;
             00)
               echo -ne " 是否卸载模块？(y/n): "
               read unput
               case "$unput" in
                 y | Y)
                   un=1
                   ;;
                 n | N)
                   un=0
                   ;;
                 *)
                   "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
                   ;;
               esac
               if [ "$un" = 1 ]; then
                   sh "$home_dir/uninstall.sh" &
                   wait
                   exit 0
               fi
               ;;
             *)
               "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！正在返回主页！\033[0m"
               ;;
           esac
           ;;
       e | E)
         clear
         exit 0
         ;;
       *)
         "$bin_dir/busybox" echo -ne "\033[1;32m 输入错误！！已经是最后一层了呦，键入 E 退出！\033[0m"
         ;;
     esac
}
######
# 运行函数
while true; do
    md_menu
sleep 0.8
done

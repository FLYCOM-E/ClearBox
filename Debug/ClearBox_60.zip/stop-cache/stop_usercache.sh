#!/system/bin/sh
#此脚本来自ClearBox模块，用于设置内部储存应用阻止缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
Appdir="/data/user/0"
Appdir2="/data/user_de/0"
blacklist="$work_dir/RunStart"
whitelist="$work_dir/whitelist.prop"
######
sdkv=$(getprop ro.build.version.sdk)
if [ "$sdkv" -lt "26" ]; then
    permission_t=771
    permission_m=551
else
    permission_t=2771
    permission_m=2551
fi
######
ls $Appdir | while read dir; do
    # 如果检测到 “com.android.xxx” 的系统核心软件则返回
    if echo "$dir" | grep ^"com.android" >dev/null; then
        continue
    # 如果该包名不是前台软件则恢复其权限
    elif ! grep "$dir" "$blacklist" >/dev/null; then
        chmod "$permission_t" "$Appdir/$dir/cache"
        chmod "$permission_t" "$Appdir2/$dir/cache"
        chmod "$permission_t" "$Appdir/$dir/code_cache"
        chmod "$permission_t" "$Appdir2/$dir/code_cache"
        continue
    # 位于前台则启用阻止缓存，位于白名单则跳过
    elif grep "$dir" "$blacklist" >/dev/null; then
        if grep "$dir" "$whitelist"; then
            continue
        fi
        chmod "$permission_m" "$Appdir/$dir/cache"
        chmod "$permission_m" "$Appdir2/$dir/cache"
        chmod "$permission_m" "$Appdir/$dir/code_cache"
        chmod "$permission_m" "$Appdir2/$dir/code_cache"
    fi
done

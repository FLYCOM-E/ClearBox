#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除内部储存软件缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
# 遍历清空软件cache文件夹
for user1cache in $(ls /data/data); do
    rm -r /data/user/0/"$user1cache"/cache/*
    rm -r /data/user/0/"$user1cache"/code_cache/*
    rm -r /data/user_de/0/"$user1cache"/cache/*
    rm -r /data/user_de/0/"$user1cache"/code_cache/*
    echo " $user1cache 缓存已清除"
done
prints 0.1@" -- 内部储存软件缓存删除完成"

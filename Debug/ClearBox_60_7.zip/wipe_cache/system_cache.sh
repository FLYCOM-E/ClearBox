#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除系统缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>>"$home_dir/LOG.log"
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
rm -r /cache/*
rm -r /data/dalvik-cache/*
rm -r /data/system/package_cache/*
rm -r /data/resource-cache/*
######
prints 0.1@" 系统缓存已清空！建议重启系统！"
exit 0

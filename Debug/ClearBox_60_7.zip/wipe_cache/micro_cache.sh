#!/system/bin/sh
#此脚本来自ClearBox模块，用于删除外部储存软件缓存
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(clearbox -b)
home_dir=$(clearbox -h)
work_dir=$(clearbox -w)
exec 2>/dev/null
######
if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
elif ! clearbox -v >/dev/null; then
    echo " 模块加载异常，请排查反馈！"
    exit
fi
######
in_dir=$(ls /mnt/expand)
k=""
if [ "$in_dir" = "$k" ]; then
    exit 0
fi
######
# 遍历清空软件cache文件夹
for microcache in $(ls /mnt/expand/*/user/0); do
    rm -r /mnt/expand/*/user/0/"$microcache"/cache/*
    rm -r /mnt/expand/*/user/0/"$microcache"/code_cache/*
    rm -r /mnt/expand/*/user_de/0/"$microcache"/cache/*
    rm -r /mnt/expand/*/user_de/0/"$microcache"/code_cache/*
    echo " $microcache 缓存已清除"
done
prints 0.1@" -- 外部储存软件缓存删除完成"

echo "
      是否安装/更新模块 WIPE-CACHE 软件？一键操作所有模块功能！"
echo "
      按下音量上键安装，触摸屏幕或任意按键取消 &&"
getevent -qlc 1 2>> /dev/null | while read -r A; do
  case $A in
    *KEY_VOLUMEUP*)
      echo "
      正在为您安装 WIPE-CACHE 软件！！"
      cp $MODPATH/APK/*WIPE*.apk $TMPDIR
      chmod 777 $TMPDIR/*WIPE*.apk
      pm install -r $TMPDIR/*WIPE*.apk
      rm $TMPDIR/*WIPE*.apk
      ;;
    *)
      echo "
      已为您取消安装！！"
  esac
done

echo "
感谢您的使用！！您的支持是我最大的动力！"
exit 0

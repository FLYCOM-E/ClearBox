#!/system/bin/sh
#此段用于删除/data/user_de内缓存
exec 2>/dev/null

ls /data/user_de/0/ | while read user2cache; do
 rm -rf /data/user_de/0/$user2cache/cache/*
 rm -rf /data/user_de/0/$user2cache/code_cache/*
 [[ $? -eq 0 ]] && echo "$user2cache 缓存已清除"
done
echo "-- user_de 缓存删除完成"

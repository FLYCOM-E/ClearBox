#!/system/bin/sh
#此脚本用于删除/data/内缓存
exec 2>/dev/null

ls /data/data/ | while read user1cache; do
 rm -rf /data/data/$user1cache/cache/*
 rm -rf /data/data/$user1cache/code_cache/*
 [[ $? -eq 0 ]] && echo "$user1cache 缓存已清除"
done
echo "-- user 缓存删除完成"

#!/system/bin/sh
#此脚本用于删除/sdcard内缓存
exec 2>/dev/null

ls /storage/emulated/0/Android/data/ | while read c; do
 rm -rf /storage/emulated/0/Android/data/$c/cache/*
 rm -rf /storage/emulated/0/Pictures/.thumbnails/*
 rm -rf /storage/emulated/0/Movies/.thumbnails/*
 rm -rf /storage/emulated/0/music/.thumbnails/*
 rm -rf /storage/emulated/0/Music/.thumbnails/*
 [[ $? -eq 0 ]] && echo "$c 缓存已清除"
done

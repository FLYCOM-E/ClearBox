#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
exec 2>/dev/null
#切至当前目录

while true; do
if [ -d "/data/app" ]; then
    chmod 771 /data/app
    break
fi
sleep 2
done
#判断/data挂载并还原app目录权限(阻止app更新功能临时还原)

while true; do
if [ -d "/storage/emulated/0/Android/data" ]; then
    break
fi
sleep 2
done
#判断是否开机

if [ -f /data/adb/wipe_cache/blacklist.txt ]; then
    cp /data/adb/wipe_cache/blacklist.txt ./stop-cache/blacklist.txt
fi
#如果黑名单存在则备份

if [ -f /data/adb/wipe_cache/log ]; then
    echo "" > /data/adb/wipe_cache/blacklist.txt
    sh ./stop-cache/all.done.sh
    wait
    rm -rf /data/adb/wipe_cache
fi
#如果阻止缓存功能被关闭则还原目录状态

if [ -f /data/adb/wipe_cache/S_stop_cache ]; then
    sh ./stop-cache/all.done.sh
    wait
    echo "上次执行时间：$(date)" >> /data/adb/wipe_cache/运行日志.log
else
    echo "您未开启阻止缓存功能！！！"
fi
#如果阻止缓存处于开启状态则执行相应脚本

if [ -f /data/adb/wipe_cache/S_stop_upapp ]; then
    chmod 551 /data/app
fi
#阻止软件更新功能

if [ -d ./APP ]; then
    rm -r ./APP
fi
#删除管理app文件

exit 0

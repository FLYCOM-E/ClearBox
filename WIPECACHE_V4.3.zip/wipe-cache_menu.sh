#!/system/bin/sh
#此脚本用于提供操作菜单
MODDIR=${0%/*}
cd "$MODDIR"
exec 2>/dev/null

chmod -R +x ./*

clear
echo "

       欢迎使用 WIPE-CACHE 操作菜单
============================================
  
    1：清除/sdcard/Android内缓存
  
    2：清除所有缓存垃圾
  
    3：清除/cache分区内容
  
    4：清除 dalvik-cache（安卓虚拟机缓存）
    
    5：阻止所有软件更新 / 安装
     
    0：阻止缓存生成功能

                       --- 键入 E 退出 ---
============================================
   
   请输入相应序号："
   read in_put
   case $in_put in

    1)
        clear
        sh wipe_cache/sdcard_cache.sh
        echo " sdcard缓存删除完成！"
        sleep 0.9
        ;;
    2)
        clear
        sh all.sh
        echo " 完成！"
        sleep 0.9
        ;;
    3)
        rm -rf /cache/*
        echo " cache分区已清空！"
        sleep 0.9
        ;;
    4)
        rm -rf /data/dalvik-cache/*
        echo " 虚拟机缓存已清空！"
        sleep 0.9
        ;;
    5)
        echo "
       APP更新安装管理 (beta！！)
============================================

    1：阻止APP更新安装
    
    2：关闭阻止更新安装

============================================

   请输入相应序号："
        read put1
        case $put1 in
         1)
           chmod 551 /data/app
           echo " 已开启阻止更新"
           touch /data/adb/wipe_cache/S_stop_upapp
           sleep 0.9
           ;;
         2)
           chmod 771 /data/app
           echo " 已关闭阻止更新"
           rm /data/adb/wipe_cache/S_stop_upapp
           sleep 0.9
           ;;
        esac
        ;;
    0)
        echo "  
              高级菜单
============================================
       自行承担一切风险 | 数据无价
           
    1：开启阻止生成缓存功能「重启生效」
  
    2：关闭阻止生成缓存功能「重启生效」
  
    3：立即生效配置
    
    4：检测开启关闭状态
  
============================================

   请输入相应序号："
        read put2
        case $put2 in
         1)
           mkdir -p /data/adb/wipe_cache
           touch /data/adb/wipe_cache/S_stop_cache
           touch /data/adb/wipe_cache/"再见缓存模块配置目录"
           echo " 已开启，重启生效 ~"
           sleep 0.9
           ;;
         2)
           touch /data/adb/wipe_cache/log
           echo " 已关闭，重启生效 ~"
           sleep 0.9
           ;;
         3)
           sh service.sh
           wait
           ;;
         4)
           if [ -f "/data/adb/wipe_cache/S_stop_cache" ]; then
           echo " 阻止缓存处于开启状态"
           sleep 0.9
           else
           echo " 阻止缓存处于关闭状态"
           sleep 0.9
           fi
           ;;
         *)
           echo " 输入错误！！"
           ;;
        esac
        sleep 0.9
        ;;
    e)
      exit 0
      ;;
    E)
      exit 0
      ;;
    *)
      echo "输入错误！！"
      ;;
   esac

sh wipe-cache_menu.sh



#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
exec 2>/dev/null

 sh wipe_cache/data_cache.sh &
 sh wipe_cache/data_cache2.sh &
 sh wipe_cache/micro_cache.sh &
 sh wipe_cache/micro_cache2.sh &
 sh wipe_cache/sdcard_cache.sh &
wait
echo "
All OK😋"
exit 0
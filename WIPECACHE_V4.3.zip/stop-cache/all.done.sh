#!/system/bin/sh
#此脚本用于判断 blacklist.txt 是否存在及复制，并启动阻止缓存脚本
MODDIR=${0%/*}
cd "$MODDIR"
exec 2>/dev/null

mkdir /data/adb/wipe_cache
if [ ! -f /data/adb/wipe_cache/blacklist.txt ]; then
    cp blacklist.txt /data/adb/wipe_cache/blacklist.txt
fi

echo "正在设置中..."
   sh stop_usercache.sh &
   sh stop_usercache2.sh &
   sh stop_micro-cache.sh &
   sh stop_micro-cache2.sh &
   wait
echo "完成！"

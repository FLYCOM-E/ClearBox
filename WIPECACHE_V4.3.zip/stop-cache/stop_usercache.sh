#!/system/bin/sh
#此脚本用于在启动后恢复非黑名单的软件缓存生成 && 此脚本用于阻止黑名单软件的缓存生成
exec 2>/dev/null

blacklist_file="/data/adb/wipe_cache/blacklist.txt"
blacklist=""

while IFS= read -r line; do
    blacklist="${blacklist}${line}"$'\n'
done < "$blacklist_file"

#读取目录
ls /data/data/ | while read a; do
    in_blacklist=0
    echo "$blacklist" | grep -q "^$a" && in_blacklist=1
    if [[ $in_blacklist -eq 0 ]]; then
        chmod 2771 /data/data/$a/cache
        chmod 2771 /data/data/$a/code_cache
    fi
done

#从黑名单文件中读取应用包名
blacklist=""
while IFS= read -r line; do
    blacklist="$blacklist $line"
done < "/data/adb/wipe_cache/blacklist.txt"
for mkdiruser1cache in $(ls /data/data/); do
    in_blacklist=0
    for blacklisted_app in $blacklist; do
        if [ "$mkdiruser1cache" = "$blacklisted_app" ]; then
            in_blacklist=1
            break
        fi
    done
    
    if [[ $in_blacklist -eq 1 ]]; then
        chmod 2551 /data/data/$mkdiruser1cache/cache
        chmod 2551 /data/data/$mkdiruser1cache/code_cache
        #如果在黑名单中，创建缓存目录并设置权限（防止无目录）
     if [[ $? -eq 0 ]]; then
         echo "“$mkdiruser1cache”已阻止生成缓存"
     fi
    fi
done

#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"

mkdir /data/adb/wipe_cache/log
echo "" > /data/adb/wipe_cache/blacklist.txt
sh service.sh &
wait

chmod 771 /data/app

exit 0

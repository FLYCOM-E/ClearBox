#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log
chmod -R 777 ./*

#切至当前目录
if [ -f $work_dir/S_stop_upapp ]; then
    chmod 771 /data/app
fi
#阻止app更新功能临时还原
while true; do
    if [ -d "/storage/emulated/0/Android/data" ]; then
        break
    fi
sleep 2
done
#判断是否开机
if [ -f $work_dir/blacklist.txt ]; then
    cp $work_dir/blacklist.txt $home_dir/stop-cache/blacklist.txt
fi
#备份黑名单
if [ -f $work_dir/log ]; then
    echo "" > $work_dir/blacklist.txt
    sh $home_dir/stop-cache/all.done.sh
    wait
    rm -rf $work_dir
fi
#阻止缓存功能被关闭则还原目录状态
if [ -f $work_dir/S_stop_cache ]; then
    sh $home_dir/stop-cache/all.done.sh
    wait
    echo " 上次运行时间：$(date)" >> $work_dir/运行日志.log
else
    echo " 您未开启阻止缓存功能！！！"
fi
#阻止缓存处于开启状态则执行相应脚本
if [ -f $work_dir/S_stop_upapp ]; then
    chmod 551 /data/app
fi
#阻止软件更新功能开启
if [ -d APK ]; then
    rm -r $home_dir/APK
fi
#删除管理app文件
exit 0

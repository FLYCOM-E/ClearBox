#!/system/bin/sh
#此脚本用于删除/data内空文件夹
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

cd /data
$bin_dir/busybox find . -type d -empty -delete

echo "-- /data 空文件夹删除完成！"
exit 0

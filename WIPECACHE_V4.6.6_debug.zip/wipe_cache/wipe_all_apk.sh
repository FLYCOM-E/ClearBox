#!/system/bin/sh
#此脚本用于删除/sdcard内所有以.apk为尾綴的文件
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

cd /storage/emulated/0/
$bin_dir/busybox find . -type f -name "*.apk" -delete

echo "-- APK 已清空！"
exit 0

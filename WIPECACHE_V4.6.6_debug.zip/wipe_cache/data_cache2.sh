#!/system/bin/sh
#此段用于删除/data/user_de内缓存
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

ls /data/user_de/0/ | while read user2cache; do
    rm -rf /data/user_de/0/$user2cache/cache/*
    rm -rf /data/user_de/0/$user2cache/code_cache/*
    [[ $? -eq 0 ]] && echo "$user2cache 缓存已清除"
done
echo "-- user_de 缓存删除完成"

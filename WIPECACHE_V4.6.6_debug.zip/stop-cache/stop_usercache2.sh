#!/system/bin/sh
#此脚本用于在启动后恢复非黑名单的软件缓存生成 && 此脚本用于阻止黑名单软件的缓存生成
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

blacklist_file="$work_dir/blacklist.txt"
blacklist=""

while IFS= read -r line; do
    blacklist="${blacklist}${line}"$'\n'
done < "$blacklist_file"
#读取目录
ls /data/user_de/0/ | while read b; do
     in_blacklist=0
     echo "$blacklist" | grep -q "^$a" && in_blacklist=1
     if [[ $in_blacklist -eq 0 ]]; then
         chmod 2771 /data/user_de/0/$b/cache
         chmod 2771 /data/user_de/0/$b/code_cache
     fi
done
#从黑名单文件中读取应用包名
blacklist=""
while IFS= read -r line; do
    blacklist="$blacklist $line"
done < "$work_dir/blacklist.txt"

for mkdiruser2cache in $(ls /data/user_de/0/); do
    in_blacklist=0
    for blacklisted_app in $blacklist; do
        if [ "$mkdiruser2cache" = "$blacklisted_app" ]; then
            in_blacklist=1
            break
        fi
    done
        if [[ $in_blacklist -eq 1 ]]; then
            chmod 2551 /data/user_de/0/$mkdiruser2cache/cache
            chmod 2551 /data/user_de/0/$mkdiruser2cache/code_cache
            #如果在黑名单中，创建缓存目录并设置权限（防止无目录）
         if [[ $? -eq 0 ]]; then
             echo "“$mkdiruser2cache”已阻止生成缓存"
         fi
        fi
done

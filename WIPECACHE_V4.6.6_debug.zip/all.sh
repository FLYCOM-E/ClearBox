#!/system/bin/sh
MODDIR=${0%/*}
cd "$MODDIR"
bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log
sh $home_dir/wipe_cache/data_cache.sh &
sh $home_dir/wipe_cache/data_cache2.sh &
sh $home_dir/wipe_cache/micro_cache.sh &
sh $home_dir/wipe_cache/micro_cache2.sh &
sh $home_dir/wipe_cache/wipe_all_apk.sh &
sh $home_dir/wipe_cache/wipe_all_dir.sh &
wait

echo "All Ok！"

#!/system/bin/sh
#此脚本用于提供magisk操作按钮，执行所有缓存删除脚本
MODDIR=${0%/*}
cd "$MODDIR"

if [ ! $(whoami) = "root" ]; then
    echo " 请授予root权限！"
    exit
fi

bin_dir=$(wipecache_bin)
home_dir=$(wipecache_home)
work_dir=$(wipecache_work)
exec 2>$home_dir/LOG.log

echo "
    ↑ 按下音量上键即刻清理缓存垃圾 ↑
    
    ↓ 按下音量下键立即生效阻止缓存配置 ↓
    
    ↔ 触摸屏幕退出 ↔"
getevent -qlc 1 2>> /dev/null | while read -r line; do
    case "$line" in
        *KEY_VOLUMEUP*)
          echo "您按下了音量上"
          sh $home_dir/all.sh
          sleep 2
          ;;
        *KEY_VOLUMEDOWN*)
          echo "您按下了音量下"
          sh $home_dir/stop-cache/all.done.sh
          sleep 2
          ;;
        *BTN_TOUCH*)
          #MTK
          echo "您选择了退出，欢迎下次光临😇"
          sleep 0
          ;;
        *ABS_MT_TRACKING_ID*)
          #QC
          echo "您选择了退出，欢迎下次光临😇"
          sleep 0
          ;;
        *)
          echo "识别失败！可能不支持识别您的设备"
          ;;
    esac
done
